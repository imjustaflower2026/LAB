Experiment 6: Naïve Bayes on 20 Newsgroups

Notebook: 20_Newsgroups_Naive_Bayes.ipynb

This version follows the local-CSV workflow and uses pandas read_csv().
Put your dataset at:
data/20_newsgroups.csv

The CSV must have a document-text column and a topic/category label column.
Common names such as text/content/document/data and target/label/category/topic are detected automatically. If your columns have different names, edit text_col and label_col in cell 5.

The notebook compares Multinomial Naïve Bayes using word counts and Bernoulli Naïve Bayes using binary word presence, then reports accuracy and weighted F1-score.

Install requirements if needed:
pip install pandas scikit-learn

Run notebook cells from top to bottom.
