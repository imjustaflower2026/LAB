Experiment 2: Auto MPG
Notebook: Auto_MPG_Dataset.ipynb
Put your existing CSV at data/mpg.csv (or beside the notebook as mpg.csv). It must have columns mpg and displacement. The notebook loads it with pandas.read_csv.
