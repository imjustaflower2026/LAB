Experiment 1: California Housing
Notebook: California_Housing_Dataset.ipynb
Place your CSV at data/california_housing.csv. The CSV should contain a target column such as MedHouseVal/target and a feature column such as AveBedrms or AveRooms. The notebook uses pandas.read_csv.
