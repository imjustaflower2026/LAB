#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <netinet/ip.h>
#include <net/ethernet.h>
#include <netpacket/packet.h>

int main()
{
    int sockfd;
    unsigned char buffer[65536];
    struct sockaddr saddr;
    socklen_t saddr_len = sizeof(saddr);

    struct ethhdr *eth;
    struct iphdr *ip;

    // Create a raw socket
    sockfd = socket(AF_PACKET, SOCK_RAW, htons(ETH_P_ALL));

    if (sockfd < 0)
    {
        perror("Socket creation failed");
        return 1;
    }

    printf("Packet Capturing Started...\n");

    while (1)
    {
        // Capture a packet
        int data_size = recvfrom(sockfd, buffer, sizeof(buffer), 0,
                                 &saddr, &saddr_len);

        if (data_size < 0)
        {
            perror("Packet capture failed");
            close(sockfd);
            return 1;
        }

        // Extract Ethernet header
        eth = (struct ethhdr *)buffer;

        printf("\n-----------------------------------\n");
        printf("Packet Captured\n");
        printf("Packet Size: %d bytes\n", data_size);

        // Check whether the packet contains an IPv4 header
        if (ntohs(eth->h_proto) == ETH_P_IP)
        {
            // Extract IP header
            ip = (struct iphdr *)(buffer + sizeof(struct ethhdr));

            struct in_addr src, dst;
            src.s_addr = ip->saddr;
            dst.s_addr = ip->daddr;

            printf("Source IP : %s\n", inet_ntoa(src));
            printf("Destination IP : %s\n", inet_ntoa(dst));

            printf("Protocol : ");

            switch (ip->protocol)
            {
                case IPPROTO_TCP:
                    printf("TCP\n");
                    break;

                case IPPROTO_UDP:
                    printf("UDP\n");
                    break;

                case IPPROTO_ICMP:
                    printf("ICMP\n");
                    break;

                default:
                    printf("Other (%d)\n", ip->protocol);
            }
        }
        else
        {
            printf("Non-IPv4 Packet\n");
        }
    }

    close(sockfd);
    return 0;
}