#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <time.h>
#include <signal.h>

#define PORT 8080
#define BUFFER_SIZE 1024

int main()
{
    int sockfd;
    struct sockaddr_in server_addr, client_addr;
    socklen_t client_len;
    char buffer[BUFFER_SIZE];

    // Create UDP socket
    sockfd = socket(AF_INET, SOCK_DGRAM, 0);

    if (sockfd < 0)
    {
        perror("Socket creation failed");
        exit(EXIT_FAILURE);
    }

    // Configure server address
    memset(&server_addr, 0, sizeof(server_addr));

    server_addr.sin_family = AF_INET;
    server_addr.sin_addr.s_addr = INADDR_ANY;
    server_addr.sin_port = htons(PORT);

    // Bind socket
    if (bind(sockfd, (struct sockaddr *)&server_addr,
             sizeof(server_addr)) < 0)
    {
        perror("Bind failed");
        close(sockfd);
        exit(EXIT_FAILURE);
    }

    printf("UDP Time Server started on port %d...\n", PORT);

    // Prevent zombie processes
    signal(SIGCHLD, SIG_IGN);

    while (1)
    {
        client_len = sizeof(client_addr);

        // Wait for client request
        int n = recvfrom(sockfd, buffer, BUFFER_SIZE - 1, 0,
                         (struct sockaddr *)&client_addr, &client_len);

        if (n < 0)
        {
            perror("recvfrom failed");
            continue;
        }
        buffer[n] = '\0';

        // Create a child process for each client
        pid_t pid = fork();

        if (pid < 0)
        {
            perror("Fork failed");
            continue;
        }

        if (pid == 0)
        {
            // Child process

            char time_string[100];

            time_t current_time;
            struct tm *time_info;

            // Get current system time
            time(&current_time);
            time_info = localtime(&current_time);

            // Convert time to readable format
            strftime(time_string, sizeof(time_string),
                     "%Y-%m-%d %H:%M:%S", time_info);

            // Send time to client
            sendto(sockfd, time_string, strlen(time_string), 0,
                   (struct sockaddr *)&client_addr,
                   client_len);

            printf("Time sent to client: %s\n", time_string);

            close(sockfd);
            exit(EXIT_SUCCESS);
        }

        // Parent continues accepting other clients
    }

    close(sockfd);
    return 0;
}