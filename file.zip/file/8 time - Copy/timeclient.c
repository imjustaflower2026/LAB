#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <sys/socket.h>

#define PORT 8080
#define BUFFER_SIZE 1024

int main(){
    int sockfd;
    struct sockaddr_in server_addr;
    char buffer[BUFFER_SIZE];
    const char *message = "TIME";

    // Create UDP socket
    sockfd = socket(AF_INET, SOCK_DGRAM, 0);
    if (sockfd < 0) {
        perror("Socket creation failed");
        exit(EXIT_FAILURE);
    }
    memset(&server_addr, 0, sizeof(server_addr));
    server_addr.sin_family = AF_INET;
    server_addr.sin_port = htons(PORT);
    // Server is running on localhost
    inet_pton(AF_INET, "127.0.0.1",
              &server_addr.sin_addr);

    // Send request to server
    sendto(sockfd, message, strlen(message), 0,
           (struct sockaddr *)&server_addr,
           sizeof(server_addr));

    // Receive time from server
    socklen_t server_len = sizeof(server_addr);
    int n = recvfrom(sockfd, buffer, BUFFER_SIZE - 1,
                     0,
                     (struct sockaddr *)&server_addr,
                     &server_len);

    if (n < 0) {
        perror("recvfrom failed");
        close(sockfd);
        exit(EXIT_FAILURE);
    }
    buffer[n] = '\0';

    printf("Current server time: %s\n", buffer);
    close(sockfd);
    return 0;
}