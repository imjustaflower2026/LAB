#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <sys/select.h>

#define PORT 5000
#define MAX_CLIENTS 10
#define BUFFER_SIZE 1024
#define NAME_SIZE 50

int main() {
    int server_fd;
    int client_socket[MAX_CLIENTS];
    char client_name[MAX_CLIENTS][NAME_SIZE];

    int i, j;
    int sd, max_sd;
    int activity, new_socket;
    char buffer[BUFFER_SIZE];
    struct sockaddr_in server_addr, client_addr;
    socklen_t addr_len = sizeof(client_addr);
    fd_set readfds;

    /* Initialize client arrays */
    for (i = 0; i < MAX_CLIENTS; i++) {
        client_socket[i] = 0;
        memset(client_name[i], 0, NAME_SIZE);
    }

    /* Create TCP socket */
    server_fd = socket(AF_INET, SOCK_STREAM, 0);
    if (server_fd < 0) {
        perror("Socket creation failed");
        exit(1);
    }

    /* Allow reuse of port */
    int opt = 1;
    if (setsockopt(server_fd, SOL_SOCKET, SO_REUSEADDR,
                   &opt, sizeof(opt)) < 0) {
        perror("setsockopt failed");
        close(server_fd);
        exit(1);
    }

    /* Server address */
    memset(&server_addr, 0, sizeof(server_addr));
    server_addr.sin_family = AF_INET;
    server_addr.sin_addr.s_addr = INADDR_ANY;
    server_addr.sin_port = htons(PORT);

    /* Bind socket */
    if (bind(server_fd, (struct sockaddr *)&server_addr, sizeof(server_addr)) < 0) {
        perror("Bind failed");
        close(server_fd);
        exit(1);
    }

    /* Listen for clients */
    if (listen(server_fd, MAX_CLIENTS) < 0) {
        perror("Listen failed");
        close(server_fd);
        exit(1);
    }

    printf("TCP Chat Server started on port %d...\n", PORT);

    while (1)
    {
        FD_ZERO(&readfds);

        /* Add server socket */
        FD_SET(server_fd, &readfds);
        max_sd = server_fd;

        /* Add all client sockets */
        for (i = 0; i < MAX_CLIENTS; i++) {
            sd = client_socket[i];
            if (sd > 0)
                FD_SET(sd, &readfds);
            if (sd > max_sd)
                max_sd = sd;
        }

        /* Wait for activity */
        activity = select(max_sd + 1, &readfds, NULL, NULL, NULL);
        if (activity < 0)
        {
            perror("select error");
            continue;
        }

        /* ------------------------------------------------
           Check for a new client connection
           ------------------------------------------------ */
        if (FD_ISSET(server_fd, &readfds)) {
            new_socket = accept(server_fd,
                                (struct sockaddr *)&client_addr,
                                &addr_len);

            if (new_socket < 0) {
                perror("Accept failed");
                continue;
            }

            /* Find an empty client slot */
            for (i = 0; i < MAX_CLIENTS; i++) {
                if (client_socket[i] == 0) {
                    client_socket[i] = new_socket;

                    /* Receive client's name */
                    memset(client_name[i], 0, NAME_SIZE);
                    int name_bytes = recv(new_socket, client_name[i], NAME_SIZE - 1, 0);

                    if (name_bytes <= 0) {
                        close(new_socket);
                        client_socket[i] = 0;
                        break;
                    }

                    client_name[i][name_bytes] = '\0';
                    printf("New user connected: %s\n", client_name[i]);
                    break;
                }
            }

            /* Server is full */
            if (i == MAX_CLIENTS) {
                printf("Maximum clients reached.\n");
                close(new_socket);
            }
        }

        /* ------------------------------------------------
           Check messages from existing clients
           ------------------------------------------------ */
        for (i = 0; i < MAX_CLIENTS; i++) {
            sd = client_socket[i];

            if (sd > 0 && FD_ISSET(sd, &readfds)) {
                memset(buffer, 0, BUFFER_SIZE);
                int bytes = recv(sd, buffer, BUFFER_SIZE - 1, 0);

                /* Client disconnected */
                if (bytes <= 0) {
                    printf("User %s disconnected.\n", client_name[i]);
                    close(sd);
                    client_socket[i] = 0;
                    memset(client_name[i], 0, NAME_SIZE);
                }
                else {
                    buffer[bytes] = '\0';

                    /* Display message on server */
                    printf("%s: %s\n", client_name[i], buffer);

                    /* Send message to all other clients */
                    for (j = 0; j < MAX_CLIENTS; j++) {
                        if (client_socket[j] > 0 &&
                            client_socket[j] != sd) {
                            char message[BUFFER_SIZE + NAME_SIZE + 10];
                            snprintf(message, sizeof(message), "%s: %s", client_name[i], buffer);

                            send(client_socket[j],
                                 message,
                                 strlen(message),
                                 0);
                        }
                    }
                }
            }
        }
    }

    close(server_fd);
    return 0;
}