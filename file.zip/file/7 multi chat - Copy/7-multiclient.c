#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <sys/select.h>

#define PORT 5000
#define BUFFER_SIZE 1024
#define NAME_SIZE 50

int main() {
    int sockfd;
    struct sockaddr_in server_addr;
    char name[NAME_SIZE];
    char message[BUFFER_SIZE];
    fd_set readfds;

    /* Create TCP socket */
    sockfd = socket(AF_INET, SOCK_STREAM, 0);
    if (sockfd < 0) {
        perror("Socket creation failed");
        exit(1);
    }

    /* Server address */
    memset(&server_addr, 0, sizeof(server_addr));
    server_addr.sin_family = AF_INET;
    server_addr.sin_port = htons(PORT);

    /* Server IP address */
    if (inet_pton(AF_INET,
                  "127.0.0.1",
                  &server_addr.sin_addr) <= 0) {
        perror("Invalid server address");
        close(sockfd);
        exit(1);
    }

    /* Connect to server */
    if (connect(sockfd,
                (struct sockaddr *)&server_addr,
                sizeof(server_addr)) < 0) {
        perror("Connection failed");
        close(sockfd);
        exit(1);
    }

    printf("Connected to chat server.\n");

    /* Enter user name */
    printf("Enter your name: ");
    fgets(name, NAME_SIZE, stdin);
    name[strcspn(name, "\n")] = '\0';

    /* Check empty name */
    if (strlen(name) == 0) {
        printf("Name cannot be empty.\n");
        close(sockfd);
        return 1;
    }

    /* Send name to server */
    send(sockfd,
         name,
         strlen(name),
         0);

    printf("You are now connected as %s.\n", name);
    printf("Type your message and press Enter.\n");
    printf("Type 'exit' to quit.\n\n");

    while (1) {
        FD_ZERO(&readfds);

        /* Monitor keyboard */
        FD_SET(STDIN_FILENO, &readfds);

        /* Monitor server */
        FD_SET(sockfd, &readfds);
        int max_fd = sockfd;

        /* Wait for keyboard or server message */
        if (select(max_fd + 1, &readfds, NULL, NULL, NULL) < 0) {
            perror("select error");
            break;
        }

        /* ------------------------------------------------
           Keyboard input
           ------------------------------------------------ */
        if (FD_ISSET(STDIN_FILENO, &readfds))
        {
            memset(message, 0, BUFFER_SIZE);
            fgets(message, BUFFER_SIZE, stdin);
            message[strcspn(message, "\n")] = '\0';

            /* Exit */
            if (strcmp(message, "exit") == 0) {
                break;
            }

            /* Don't send empty messages */
            if (strlen(message) == 0)
                continue;

            /* Send message to server */
            send(sockfd,
                 message,
                 strlen(message),
                 0);
        }

        /* ------------------------------------------------
           Message received from server
           ------------------------------------------------ */
        if (FD_ISSET(sockfd, &readfds)) {
            memset(message, 0, BUFFER_SIZE);
            int bytes = recv(sockfd,
                             message,
                             BUFFER_SIZE - 1,
                             0);

            if (bytes <= 0) {
                printf("\nServer disconnected.\n");
                break;
            }

            message[bytes] = '\0';
            printf("\n%s\n", message);
            printf("You: ");
            fflush(stdout);
        }
    }

    close(sockfd);
    printf("Disconnected from server.\n");
    return 0;
}