#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>

#define PORT 8080

int main()
{
    int server, client;
    int n, matrix[50][50];
    char *result;

    // 1. Create socket
    server = socket(AF_INET, SOCK_STREAM, 0);
    if (server < 0)
    {
        printf("Socket creation failed\n");
        return 1;
    }

    // Allow port reuse
    int opt = 1;
    setsockopt(server, SOL_SOCKET, SO_REUSEADDR, &opt, sizeof(opt));

    // 2. Bind to port
    struct sockaddr_in addr;
    addr.sin_family = AF_INET;
    addr.sin_port = htons(PORT);
    addr.sin_addr.s_addr = INADDR_ANY;
    if (bind(server, (struct sockaddr*)&addr, sizeof(addr)) < 0)
    {
        printf("Bind failed\n");
        return 1;
    }

    // 3. Listen for connections
    listen(server, 1);
    printf("Server waiting for client on port %d...\n", PORT);

    // 4. Accept connection
    client = accept(server, NULL, NULL);
    if (client < 0)
    {
        printf("Accept failed\n");
        return 1;
    }
    printf("Client connected!\n");

    // 5. Receive matrix size N
    recv(client, &n, sizeof(int), 0);
    printf("Matrix size received: %d x %d\n", n, n);

    // 6. Receive matrix elements
    for (int i = 0; i < n; i++)
        for (int j = 0; j < n; j++)
            recv(client, &matrix[i][j], sizeof(int), 0);

    // 7. Print received matrix
    printf("Received Matrix:\n");
    for (int i = 0; i < n; i++)
    {
        for (int j = 0; j < n; j++)
            printf("%4d", matrix[i][j]);
        printf("\n");
    }

    // 8. Check matrix type
    int sym = 1, diag = 1, upper = 1, lower = 1, ident = 1;

    for (int i = 0; i < n; i++)
        for (int j = 0; j < n; j++)
        {
            if (matrix[i][j] != matrix[j][i]) sym = 0;
            if (i != j && matrix[i][j] != 0) diag = 0;
            if (i > j && matrix[i][j] != 0) upper = 0;
            if (i < j && matrix[i][j] != 0) lower = 0;
            if (i == j && matrix[i][j] != 1) ident = 0;
            if (i != j && matrix[i][j] != 0) ident = 0;
        }

    if (ident)
        result = "Identity Matrix";
    else if (diag)
        result = "Diagonal Matrix";
    else if (upper)
        result = "Upper Triangular Matrix";
    else if (lower)
        result = "Lower Triangular Matrix";
    else if (sym)
        result = "Symmetric Matrix";
    else
        result = "General Matrix";

    // 9. Send the result to the client
    send(client, result, strlen(result) + 1, 0);
    printf("Result sent to client: %s\n", result);

    // 10. Close connections
    close(client);
    close(server);

    return 0;
}