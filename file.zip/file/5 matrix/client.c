#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <time.h>

#define PORT 8080
#define MAXN 20

int main()
{
    int sock, N, matrix[MAXN][MAXN];
    char result[64];
    struct sockaddr_in addr;

    // 1. Get matrix size from user
    printf("Enter matrix order N: ");
    scanf("%d", &N);

    // 2. Generate a random matrix
    srand(time(NULL));

    int type = rand() % 3;

    printf("Generated %d x %d Matrix:\n", N, N);

    for (int i = 0; i < N; i++)
    {
        for (int j = 0; j < N; j++)
        {
            if (type == 0)
            {
                // Upper Triangular Matrix
                if (i <= j)
                    matrix[i][j] = rand() % 50 + 1;
                else
                    matrix[i][j] = 0;
            }
            else if (type == 1)
            {
                // Lower Triangular Matrix
                if (i >= j)
                    matrix[i][j] = rand() % 50 + 1;
                else
                    matrix[i][j] = 0;
            }
            else
            {
                // Diagonal Matrix
                if (i == j)
                    matrix[i][j] = rand() % 50 + 1;
                else
                    matrix[i][j] = 0;
            }

            printf("%4d", matrix[i][j]);
        }
        printf("\n");
    }

    // 3. Create socket
    sock = socket(AF_INET, SOCK_STREAM, 0);
    if (sock < 0)
    {
        printf("Socket creation failed\n");
        return 1;
    }

    // 4. Connect to server
    addr.sin_family = AF_INET;
    addr.sin_port = htons(PORT);
    inet_pton(AF_INET, "127.0.0.1", &addr.sin_addr);

    if (connect(sock, (struct sockaddr*)&addr, sizeof(addr)) < 0)
    {
        printf("Connection to server failed\n");
        return 1;
    }

    printf("Connected to server!\n");

    // 5. Send matrix size N
    send(sock, &N, sizeof(int), 0);

    // 6. Send matrix elements one by one
    for (int i = 0; i < N; i++)
        for (int j = 0; j < N; j++)
            send(sock, &matrix[i][j], sizeof(int), 0);

    // 7. Receive and print the result
    recv(sock, result, sizeof(result), 0);
    printf("Server identified matrix as: %s\n", result);

    // 8. Close socket
    close(sock);

    return 0;
}