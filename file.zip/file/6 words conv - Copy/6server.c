#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <unistd.h>

#define PORT 5000
#define BUFFER_SIZE 1024

void translateToFormal(char *input, char *output)
{
    char *word;
    char temp[BUFFER_SIZE];
    char *token;

    output[0] = '\0';

    strcpy(temp, input);

    token = strtok(temp, " ");

    while (token != NULL)
    {
        if (strcmp(token, "pls,") == 0)
            strcat(output, "please, ");
        else if (strcmp(token, "pls") == 0)
            strcat(output, "please ");
        else if (strcmp(token, "don't") == 0)
            strcat(output, "do not ");
        else if (strcmp(token, "wanna") == 0)
            strcat(output, "want to ");
        else if (strcmp(token, "gonna") == 0)
            strcat(output, "going to ");
        else if (strcmp(token, "can't") == 0)
            strcat(output, "cannot ");
        else if (strcmp(token, "I'm") == 0)
            strcat(output, "I am ");
        else if (strcmp(token, "thanks") == 0)
            strcat(output, "thank you ");
        else
        {
            strcat(output, token);
            strcat(output, " ");
        }

        token = strtok(NULL, " ");
    }

    // Remove final extra space
    int len = strlen(output);
    if (len > 0 && output[len - 1] == ' ')
        output[len - 1] = '\0';
}

int main()
{
    int sockfd;
    char buffer[BUFFER_SIZE];
    char formal[BUFFER_SIZE];

    struct sockaddr_in server_addr, client_addr;
    socklen_t client_len = sizeof(client_addr);

    sockfd = socket(AF_INET, SOCK_DGRAM, 0);

    if (sockfd < 0)
    {
        perror("Socket creation failed");
        exit(1);
    }

    memset(&server_addr, 0, sizeof(server_addr));

    server_addr.sin_family = AF_INET;
    server_addr.sin_addr.s_addr = INADDR_ANY;
    server_addr.sin_port = htons(PORT);

    if (bind(sockfd, (struct sockaddr *)&server_addr,
             sizeof(server_addr)) < 0)
    {
        perror("Bind failed");
        close(sockfd);
        exit(1);
    }

    printf("UDP Server is waiting for messages...\n");

    while (1)
    {
        memset(buffer, 0, BUFFER_SIZE);
        memset(formal, 0, BUFFER_SIZE);

        recvfrom(sockfd, buffer, BUFFER_SIZE - 1, 0,
                 (struct sockaddr *)&client_addr, &client_len);

        printf("Received: %s\n", buffer);

        translateToFormal(buffer, formal);

        sendto(sockfd, formal, strlen(formal), 0,
               (struct sockaddr *)&client_addr, client_len);

        printf("Sent: %s\n", formal);
    }

    close(sockfd);

    return 0;
}