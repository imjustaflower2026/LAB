#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <unistd.h>

#define PORT 5000
#define BUFFER_SIZE 1024

int main()
{
    int sockfd;
    char sentence[BUFFER_SIZE];
    char buffer[BUFFER_SIZE];
    struct sockaddr_in server_addr;
    socklen_t server_len = sizeof(server_addr);

    // Create UDP socket
    sockfd = socket(AF_INET, SOCK_DGRAM, 0);
    if (sockfd < 0) {
        perror("Socket creation failed");
        exit(1);
    }

    // Clear server address
    memset(&server_addr, 0, sizeof(server_addr));
    server_addr.sin_family = AF_INET;
    server_addr.sin_port = htons(PORT);

    // Server IP address
    inet_pton(AF_INET, "127.0.0.1", &server_addr.sin_addr);

    // Get sentence from user
    printf("Enter a new-generation English sentence: ");
    fgets(sentence, BUFFER_SIZE, stdin);

    // Remove newline
    sentence[strcspn(sentence, "\n")] = '\0';

    // Send sentence to server
    sendto(sockfd, sentence, strlen(sentence), 0,
           (struct sockaddr *)&server_addr, server_len);

    // Receive translated sentence
    memset(buffer, 0, BUFFER_SIZE);

    recvfrom(sockfd, buffer, BUFFER_SIZE - 1, 0,
             (struct sockaddr *)&server_addr, &server_len);

    printf("Formal English: %s\n", buffer);
    close(sockfd);
    return 0;
}