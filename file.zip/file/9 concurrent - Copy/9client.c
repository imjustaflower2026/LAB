#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>

#define PORT 8080
#define BUFFER_SIZE 1024

int main() {
    int sockfd;
    struct sockaddr_in server_addr;
    char filename[BUFFER_SIZE];
    char buffer[BUFFER_SIZE];
    int bytes_received;

    /* Create TCP socket */
    sockfd = socket(AF_INET, SOCK_STREAM, 0);
    if (sockfd < 0) {
        perror("Socket creation failed");
        exit(EXIT_FAILURE);
    }

    /* Initialize server address */
    memset(&server_addr, 0, sizeof(server_addr));
    server_addr.sin_family = AF_INET;
    server_addr.sin_port = htons(PORT);

    /* Connect to localhost */
    if (inet_pton(AF_INET, "127.0.0.1", &server_addr.sin_addr) <= 0) {
        perror("Invalid server address");
        close(sockfd);
        exit(EXIT_FAILURE);
    }

    /* Connect to server */
    if (connect(sockfd, (struct sockaddr *)&server_addr, sizeof(server_addr)) < 0) {
        perror("Connection failed");
        close(sockfd);
        exit(EXIT_FAILURE);
    }

    printf("Connected to server.\n");

    /* Receive server PID */
    memset(buffer, 0, sizeof(buffer));
    bytes_received = recv(sockfd, buffer, sizeof(buffer) - 1, 0);
    if (bytes_received > 0) {
        buffer[bytes_received] = '\0';
        printf("%s", buffer);
    }

    /* Get filename from user */
    printf("Enter filename: ");
    if (fgets(filename, sizeof(filename), stdin) == NULL) {
        close(sockfd);
        exit(EXIT_FAILURE);
    }

    /* Remove newline */
    filename[strcspn(filename, "\r\n")] = '\0';
    if (strlen(filename) == 0) {
        printf("Filename cannot be empty.\n");
        close(sockfd);
        exit(EXIT_FAILURE);
    }

    /* Send filename to server */
    send(sockfd, filename, strlen(filename), 0);

    printf("\nServer response:\n");

    /* Receive file/error response.
       The server sends:
       1. FILE_FOUND + file contents + END_OF_FILE
       OR
       2. ERROR message */
    while ((bytes_received = recv(sockfd, buffer, sizeof(buffer) - 1, 0)) > 0) {
        buffer[bytes_received] = '\0';
        printf("%s", buffer);

        /* Stop after receiving END_OF_FILE. */
        if (strstr(buffer, "END_OF_FILE") != NULL) {
            break;
        }

        /* Stop if the server says the file doesn't exist. */
        if (strstr(buffer, "ERROR:") != NULL) {
            break;
        }
    }

    printf("\nConnection closed.\n");
    close(sockfd);
    return 0;
}