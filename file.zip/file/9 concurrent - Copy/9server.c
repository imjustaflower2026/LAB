#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <signal.h>

#define PORT 8080
#define BUFFER_SIZE 1024

int main() {
    int server_fd, client_fd;
    struct sockaddr_in server_addr, client_addr;
    socklen_t client_len;
    char filename[BUFFER_SIZE];
    char buffer[BUFFER_SIZE];
    FILE *file;
    pid_t pid;

    /* Create TCP socket */
    server_fd = socket(AF_INET, SOCK_STREAM, 0);
    if (server_fd < 0) {
        perror("Socket creation failed");
        exit(EXIT_FAILURE);
    }

    /* Allow reuse of the port */
    int opt = 1;
    if (setsockopt(server_fd, SOL_SOCKET, SO_REUSEADDR, &opt, sizeof(opt)) < 0) {
        perror("setsockopt failed");
        close(server_fd);
        exit(EXIT_FAILURE);
    }

    /* Initialize server address */
    memset(&server_addr, 0, sizeof(server_addr));
    server_addr.sin_family = AF_INET;
    server_addr.sin_addr.s_addr = INADDR_ANY;
    server_addr.sin_port = htons(PORT);

    /* Bind socket */
    if (bind(server_fd, (struct sockaddr *)&server_addr, sizeof(server_addr)) < 0) {
        perror("Bind failed");
        close(server_fd);
        exit(EXIT_FAILURE);
    }

    /* Listen for clients */
    if (listen(server_fd, 10) < 0) {
        perror("Listen failed");
        close(server_fd);
        exit(EXIT_FAILURE);
    }

    /* Ignore SIGCHLD to prevent zombie processes */
    signal(SIGCHLD, SIG_IGN);

    printf("========================================\n");
    printf("  Concurrent TCP File Server\n");
    printf("========================================\n");
    printf("Server listening on port %d\n", PORT);
    printf("Server PID: %d\n", getpid());
    printf("Waiting for clients...\n\n");

    while (1) {
        client_len = sizeof(client_addr);

        /* Accept client connection */
        client_fd = accept(server_fd, (struct sockaddr *)&client_addr, &client_len);
        if (client_fd < 0) {
            perror("Accept failed");
            continue;
        }

        printf("Client connected: %s\n", inet_ntoa(client_addr.sin_addr));

        /* Create child process */
        pid = fork();
        if (pid < 0) {
            perror("Fork failed");
            close(client_fd);
            continue;
        }

        if (pid == 0) {
            /* Child process */

            /* Child does not need the listening socket */
            close(server_fd);

            /* Send child/server process PID to client */
            snprintf(buffer, sizeof(buffer), "Server PID: %d\n", getpid());
            send(client_fd, buffer, strlen(buffer), 0);

            /* Receive filename */
            memset(filename, 0, sizeof(filename));
            int bytes_received = recv(client_fd, filename, sizeof(filename) - 1, 0);
            if (bytes_received <= 0) {
                close(client_fd);
                exit(EXIT_SUCCESS);
            }
            filename[bytes_received] = '\0';

            /* Remove newline */
            filename[strcspn(filename, "\r\n")] = '\0';
            printf("Client requested file: %s\n", filename);

            /* Open requested file */
            file = fopen(filename, "rb");
            if (file == NULL) {
                /* Do not include the filename in the error message. */
                const char *error_message = "ERROR: File does not exist.\n";
                send(client_fd, error_message, strlen(error_message), 0);
                close(client_fd);
                exit(EXIT_SUCCESS);
            }

            /* Inform client that file exists */
            const char *success_message = "FILE_FOUND\n";
            send(client_fd, success_message, strlen(success_message), 0);

            /* Read and send file contents */
            while (1) {
                size_t bytes_read;
                bytes_read = fread(buffer, 1, sizeof(buffer), file);

                if (bytes_read > 0) {
                    size_t total_sent = 0;
                    while (total_sent < bytes_read) {
                        ssize_t bytes_sent;
                        bytes_sent = send(client_fd, buffer + total_sent,
                                          bytes_read - total_sent, 0);
                        if (bytes_sent <= 0) {
                            break;
                        }
                        total_sent += bytes_sent;
                    }
                }

                if (bytes_read < sizeof(buffer)) {
                    break;
                }
            }

            fclose(file);

            /* Tell client that file transfer is complete */
            const char *end_message = "\nEND_OF_FILE\n";
            send(client_fd, end_message, strlen(end_message), 0);

            printf("File sent successfully to client.\n\n");
            close(client_fd);
            exit(EXIT_SUCCESS);
        }
        else {
            /* Parent process does not need client socket */
            close(client_fd);
        }
    }

    close(server_fd);
    return 0;
}