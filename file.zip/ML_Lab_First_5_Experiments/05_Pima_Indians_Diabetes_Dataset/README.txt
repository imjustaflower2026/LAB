Experiment 5 - Logistic Regression with vs without Scaling (Pima)

Notebook code is based on Experiments 1–5 in the supplied PDF. Comments have been removed and the code is split into separate Jupyter cells.

Install common packages:
python -m pip install pandas numpy matplotlib scikit-learn

Dataset notes:
- Experiment 1: California Housing is fetched by scikit-learn on first run and may require internet.
- Experiment 2: place mpg.csv in this experiment's data folder. Required columns: mpg and displacement.
- Experiment 3: Diabetes dataset is included in scikit-learn.
- Experiment 4: Breast Cancer dataset is included in scikit-learn.
- Experiment 5: place pima_indians_diabetes.csv in this experiment's data folder. The notebook expects the original headerless 9-column Pima CSV.

Run the notebook cells from top to bottom. To use a different CSV location, change CSV_PATH to your file path.
